package newpackage;

public class PasswordUtils {
    public static String hashPassword(String password) {
        return Integer.toString(password.hashCode());
    }
}
