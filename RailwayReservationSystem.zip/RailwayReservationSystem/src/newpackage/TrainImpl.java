package newpackage;

public class TrainImpl extends Train {
    public TrainImpl(String trainName, String source, String destination, int availableSeats, String travelTime) {
        super(trainName, source, destination, availableSeats, travelTime);
    }
}
